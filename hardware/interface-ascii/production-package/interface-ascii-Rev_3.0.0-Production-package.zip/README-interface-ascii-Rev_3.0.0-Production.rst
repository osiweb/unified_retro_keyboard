interface-ascii Rev 3.0.0 (Unified retro keyboard ASCII interface, ATMega 328P version) 
-----------------------------------------------------------------------------------------------
 
This is the package for interface-ascii rev 3.0.0.
 
Service Requested 
=================
 
   * Manufacturing and inspection to IPC class 3 standard. 
   * RoHS compliant 
   * PCB Material: FR4 
   * Solder mask color: Green 
   * Silk screen color: White 
   * Layers: 2 
   * Copper thickness: 1 oz all layers 
   * Finish: HASL
 

Programming and labeling of microcontroller 
===========================================
 
None 

Testing 
======= 
   * Test 100% testing of assemblies 
   * Standard PCB QA (bed of nails, test for shorts and opens) 
 

Tracking 
========
 
None 
 

Packaging 
=========
 
Standard Packaging 

Production Package 
==================
 
The  ZIP file contains the following files: 
   interface-ascii-Rev_3-pcbfab.zip 
   A ZIP file containing Gerbers; drill file; 
   readme.txt 
      readme file containing PCB fabrication directions; fab renderings, etc. 
 
 
   This letter. 
 
Renderings-top-interface-ascii-Rev_3-Production.jpg 
   A JPEG file containing a reference for PCB parts placement, and 3D renderings of the front of the populated board (with components). 
 
Renderings-bottom-interface-ascii-Rev_3-Production.jpg 
   A JPEG file containing a reference for PCB parts placement, and 3D renderings of the back of the populated board (with components). 
 
Model-3D-interface-ascii-Rev_3-Production.STEP: 
   An exported 3D STEP file of the PCB with all components fitted. 
 
Schematic-interface-ascii-Rev_3.0.0-Production.pdf 
   A PDF file containing the schematics for this PCB. 
 
BOM-interface-ascii-Rev_3.0-Production.csv 
   BOM file, csv format 
 
Subdirectory: labels_dir 
   :_labels.doc: Labels for final packaging. 
 
Subdirectory: programming_files_dir 
   empty, not applicable. 
 
Subdirectory containing programming files 
   empty, not applicable 
 
Subdirectory: diagrams_dir 
   empty 
 
Subdirectory containing diagrams or pictures related to production 
   empty 
 
Subdirectory: work_instructions_dir 
   Subdirectory containing work instructions, test procedures, etc.
 
.. figure:: ./Renderings-top-interface-ascii-Rev_3-Production.jpg
 
   TOP side rendering of populated PCB 
.. figure:: ./Renderings-bottom-interface-ascii-Rev_3-Production.jpg
 
   BOTTOM side rendering of populated PCB
